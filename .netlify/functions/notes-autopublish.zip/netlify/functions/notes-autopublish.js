var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var notes_autopublish_exports = {};
__export(notes_autopublish_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(notes_autopublish_exports);
var import_supabase_js = require("@supabase/supabase-js");
var import_resend = require("resend");
const supabase = (0, import_supabase_js.createClient)(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);
const resend = new import_resend.Resend(process.env.RESEND_API_KEY);
const handler = async (event, context) => {
  if (event.httpMethod !== "POST" && !event.headers["x-netlify-cron"]) {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    console.log("\u{1F680} Starting autopublish pipeline...");
    const researchTopic = await getNextResearchTopic();
    if (!researchTopic) {
      console.log("No research topics in queue, seeding...");
      await seedResearchQueue();
      return {
        statusCode: 200,
        body: JSON.stringify({
          success: true,
          action: "queue_seeded",
          message: "Research queue seeded for next run"
        })
      };
    }
    console.log(`\u{1F4DA} Processing topic: ${researchTopic.topic}`);
    await updateTopicStatus(researchTopic.id, "researching");
    const researchData = await conductResearch(researchTopic.topic);
    await updateTopicStatus(researchTopic.id, "drafted");
    const draftContent = await generateDraft(researchTopic, researchData);
    await updateTopicStatus(researchTopic.id, "editing");
    const editedContent = await editContent(draftContent);
    const styledContent = await enforceStyle(editedContent, researchTopic.intent);
    const qualityCheck = await performQualityCheck(styledContent, researchData);
    if (!qualityCheck.passed) {
      console.warn("Quality check failed:", qualityCheck.issues);
      if (qualityCheck.canRetry) {
        const reEditedContent = await editContent(styledContent, qualityCheck.feedback);
        const reStyledContent = await enforceStyle(reEditedContent, researchTopic.intent);
        const finalCheck = await performQualityCheck(reStyledContent, researchData);
        if (!finalCheck.passed) {
          throw new Error("Content failed quality check twice");
        }
        styledContent = reStyledContent;
      } else {
        throw new Error("Content failed critical quality check");
      }
    }
    const draft = await saveDraft({
      title: styledContent.title,
      summary: styledContent.summary,
      body_mdx: styledContent.body,
      research_queue_id: researchTopic.id,
      status: "ready"
    });
    const ogImagePath = await generateOGImage(draft.slug, styledContent.title);
    await supabase.from("drafts").update({ og_path: ogImagePath }).eq("id", draft.id);
    await publishDraft(draft.id, styledContent);
    await notifyMembersOfNewNote(draft, styledContent);
    await updateTopicStatus(researchTopic.id, "published");
    return {
      statusCode: 200,
      body: JSON.stringify({
        success: true,
        action: "published",
        draft: {
          id: draft.id,
          slug: draft.slug,
          title: styledContent.title,
          url: `https://peycheff.com/notes/${draft.slug}`
        },
        stats: {
          research_sources: researchData.sources?.length || 0,
          word_count: styledContent.word_count,
          quality_score: qualityCheck.score
        }
      })
    };
  } catch (error) {
    console.error("Autopublish pipeline error:", error);
    await notifyPipelineFailure(error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: "Pipeline failed",
        details: process.env.NODE_ENV === "development" ? error.message : void 0
      })
    };
  }
};
async function getNextResearchTopic() {
  const { data, error } = await supabase.from("research_queue").select("*").eq("status", "queued").order("priority", { ascending: false }).order("scheduled_for", { ascending: true }).limit(1).single();
  if (error && error.code !== "PGRST116") {
    console.error("Error fetching research topic:", error);
    return null;
  }
  return data;
}
async function seedResearchQueue() {
  const topics = [
    { topic: "AI-First Product Development", intent: "note", priority: 1 },
    { topic: "Founder Operating Systems", intent: "note", priority: 1 },
    { topic: "Revenue Architecture Design", intent: "note", priority: 1 },
    { topic: "Zero-Touch Automation Playbook", intent: "kit", priority: 2 },
    { topic: "Team Process Optimization", intent: "note", priority: 1 },
    { topic: "Customer Success Automation", intent: "note", priority: 1 }
  ];
  const { error } = await supabase.from("research_queue").upsert(topics.map((topic) => ({
    ...topic,
    scheduled_for: (/* @__PURE__ */ new Date()).toISOString()
  })));
  if (error) {
    console.error("Error seeding research queue:", error);
    throw error;
  }
}
async function conductResearch(topic) {
  try {
    const response = await fetch("https://api.perplexity.ai/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${process.env.PERPLEXITY_API_KEY}`
      },
      body: JSON.stringify({
        model: "llama-3.1-sonar-small-128k-online",
        messages: [
          {
            role: "user",
            content: `Research current trends, data, and insights about "${topic}" for founders and operators. Focus on:
            - Recent developments and statistics (last 12 months)
            - Practical frameworks and methodologies
            - Real company examples and case studies
            - Common pitfalls and anti-patterns
            - Actionable insights for implementation
            
            Provide factual, source-backed information suitable for a technical founder audience.`
          }
        ],
        max_tokens: 2e3,
        temperature: 0.1
      })
    });
    if (!response.ok) {
      throw new Error(`Perplexity API failed: ${response.statusText}`);
    }
    const result = await response.json();
    const researchContent = result.choices[0].message.content;
    return {
      topic,
      content: researchContent,
      sources: extractSources(researchContent),
      researched_at: (/* @__PURE__ */ new Date()).toISOString(),
      word_count: researchContent.split(" ").length
    };
  } catch (error) {
    console.error("Research phase error:", error);
    return {
      topic,
      content: `Current research on ${topic} shows significant evolution in founder approaches...`,
      sources: [],
      researched_at: (/* @__PURE__ */ new Date()).toISOString(),
      word_count: 100,
      fallback: true
    };
  }
}
function extractSources(content) {
  const urlRegex = /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)/g;
  const sources = content.match(urlRegex) || [];
  return [...new Set(sources)];
}
async function generateDraft(researchTopic, researchData) {
  const prompt = `Write an operator note for founders on "${researchTopic.topic}".

Research context:
${researchData.content}

Structure:
1. Context (the real pain) - What's the problem/opportunity?
2. System (steps/tools/operating cadence) - How to solve it
3. Result (metrics to track + pitfalls) - What to measure and avoid

Style guide:
- Tone: blunt, dry-humor, street-smart, visionary like Ivan Peychev
- No fluff or buzzwords
- Max 3-line paragraphs
- Apple-clean microcopy
- 900-1,200 words
- End with a small buy box suggestion for relevant product

Make it actionable for technical founders who want systems that work.`;
  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${process.env.ANTHROPIC_API_KEY}`,
        "anthropic-version": "2023-06-01"
      },
      body: JSON.stringify({
        model: "claude-3-5-sonnet-20241022",
        max_tokens: 2e3,
        messages: [
          {
            role: "user",
            content: prompt
          }
        ]
      })
    });
    if (!response.ok) {
      throw new Error(`Claude API failed: ${response.statusText}`);
    }
    const result = await response.json();
    const content = result.content[0].text;
    return {
      raw_content: content,
      word_count: content.split(" ").length,
      generated_at: (/* @__PURE__ */ new Date()).toISOString()
    };
  } catch (error) {
    console.error("Draft generation error:", error);
    throw error;
  }
}
async function editContent(draftContent, feedback = null) {
  const prompt = `Tighten and edit this operator note. ${feedback ? `Feedback to address: ${feedback}` : ""}

Content to edit:
${draftContent.raw_content || draftContent}

Editing rules:
- Remove filler words and redundancy
- Enforce max 3-line paragraphs
- Convert passive voice to active
- Apple-style microcopy (clear, direct, human)
- Maintain blunt, street-smart tone
- Ensure logical flow between sections
- Return clean MDX format

Return the edited content with:
- Clear H2 sections
- Proper MDX formatting
- A one-line summary (meta description style)`;
  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: "gpt-4",
        messages: [
          {
            role: "system",
            content: "You are a technical editor specializing in founder/operator content. Edit for clarity, impact, and Apple-grade simplicity."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        max_tokens: 2e3,
        temperature: 0.3
      })
    });
    if (!response.ok) {
      throw new Error(`OpenAI API failed: ${response.statusText}`);
    }
    const result = await response.json();
    return result.choices[0].message.content;
  } catch (error) {
    console.error("Edit phase error:", error);
    throw error;
  }
}
async function enforceStyle(editedContent, intent) {
  const lines = editedContent.split("\n").filter((line) => line.trim());
  const title = extractTitle(lines);
  const summary = extractSummary(lines);
  const buyBox = generateBuyBox(intent, title);
  const body = cleanAndStructureMDX(editedContent, buyBox);
  return {
    title: title || "Untitled Note",
    summary: summary || "Operator insights for founders",
    body,
    word_count: body.split(" ").length,
    intent
  };
}
function extractTitle(lines) {
  const h1Line = lines.find((line) => line.startsWith("# "));
  if (h1Line) return h1Line.replace("# ", "");
  const firstLine = lines.find((line) => line.length > 10 && !line.startsWith("#"));
  return firstLine?.substring(0, 60) + "..." || null;
}
function extractSummary(lines) {
  const summaryLine = lines.find((line) => line.toLowerCase().includes("summary:"));
  if (summaryLine) return summaryLine.replace(/summary:\s*/i, "");
  const firstParagraph = lines.find(
    (line) => line.length > 50 && !line.startsWith("#") && !line.includes("**")
  );
  return firstParagraph?.substring(0, 160) + "..." || null;
}
function generateBuyBox(intent, title) {
  const buyBoxes = {
    note: {
      product: "MEMBER_MONTHLY",
      text: "Get operator memos like this twice monthly",
      cta: "Join Build Notes"
    },
    kit: {
      product: "KIT_AUTOMATION",
      text: "Want the automation playbooks?",
      cta: "Get the Kit"
    },
    diagram: {
      product: "KIT_DIAGRAMS",
      text: "System diagrams for your team",
      cta: "Download Library"
    }
  };
  const box = buyBoxes[intent] || buyBoxes.note;
  return `
## Try This

${box.text}. No fluff, just systems that work.

<BuyButton product="${box.product}">${box.cta}</BuyButton>
`;
}
function cleanAndStructureMDX(content, buyBox) {
  let cleaned = content.replace(/## Try This[\s\S]*?<BuyButton[^>]*>.*?<\/BuyButton>/g, "");
  cleaned = cleaned.replace(/^# /gm, "## ");
  const conclusionIndex = cleaned.toLowerCase().indexOf("## conclusion");
  if (conclusionIndex > -1) {
    cleaned = cleaned.substring(0, conclusionIndex) + buyBox + "\n\n" + cleaned.substring(conclusionIndex);
  } else {
    cleaned = cleaned + "\n\n" + buyBox;
  }
  return cleaned.trim();
}
async function performQualityCheck(content, researchData) {
  const issues = [];
  let score = 100;
  const wordCount = content.body.split(" ").length;
  if (wordCount < 800) {
    issues.push("Content too short (< 800 words)");
    score -= 20;
  }
  if (wordCount > 1500) {
    issues.push("Content too long (> 1500 words)");
    score -= 10;
  }
  if (!content.body.includes("## ")) {
    issues.push("Missing proper section headers");
    score -= 15;
  }
  if (!content.body.includes("<BuyButton")) {
    issues.push("Missing buy box");
    score -= 10;
  }
  if (researchData.content && !researchData.fallback) {
    const similarity = calculateSimilarity(content.body, researchData.content);
    if (similarity > 0.3) {
      issues.push(`High similarity to source material (${Math.round(similarity * 100)}%)`);
      score -= 25;
    }
  }
  return {
    passed: score >= 70,
    canRetry: score >= 50,
    score,
    issues,
    feedback: issues.length > 0 ? `Address these issues: ${issues.join(", ")}` : null
  };
}
function calculateSimilarity(text1, text2) {
  const words1 = new Set(text1.toLowerCase().split(/\s+/));
  const words2 = new Set(text2.toLowerCase().split(/\s+/));
  const intersection = new Set([...words1].filter((word) => words2.has(word)));
  const union = /* @__PURE__ */ new Set([...words1, ...words2]);
  return intersection.size / union.size;
}
async function saveDraft(draftData) {
  const slug = generateSlug(draftData.title);
  const { data, error } = await supabase.from("drafts").insert({
    ...draftData,
    slug
  }).select().single();
  if (error) {
    console.error("Error saving draft:", error);
    throw error;
  }
  return data;
}
async function publishDraft(draftId, content) {
  const { error } = await supabase.from("drafts").update({
    status: "published",
    published_at: (/* @__PURE__ */ new Date()).toISOString()
  }).eq("id", draftId);
  if (error) {
    console.error("Error publishing draft:", error);
    throw error;
  }
}
async function notifyMembersOfNewNote(draft, content) {
  const { data: members, error } = await supabase.from("has_membership").select("email").eq("is_active_member", true);
  if (error) {
    console.error("Error fetching members:", error);
    return;
  }
  if (!members?.length) {
    console.log("No active members to notify");
    return;
  }
  const noteUrl = `https://peycheff.com/notes/${draft.slug}`;
  const emailPromises = members.map(
    (member) => resend.emails.send({
      from: "Ivan Peychev <ivan@peycheff.com>",
      to: member.email,
      subject: `New note: ${content.title}`,
      html: `
        <div style="font-family: -apple-system, system-ui, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h1 style="font-size: 24px; margin: 0 0 16px 0;">${content.title}</h1>
          <p style="font-size: 16px; color: #666; margin: 0 0 24px 0;">${content.summary}</p>
          <a href="${noteUrl}" style="display: inline-block; background: #0a84ff; color: white; text-decoration: none; padding: 12px 24px; border-radius: 8px; font-weight: 600;">Read Full Note</a>
          <hr style="margin: 40px 0; border: none; border-top: 1px solid #eee;">
          <p style="font-size: 14px; color: #999;">You're receiving this as a Build Notes member. <a href="https://peycheff.com/members">Manage subscription</a></p>
        </div>
      `
    })
  );
  await Promise.allSettled(emailPromises);
  console.log(`Notified ${members.length} members of new note: ${draft.slug}`);
}
async function updateTopicStatus(topicId, status) {
  const { error } = await supabase.from("research_queue").update({ status }).eq("id", topicId);
  if (error) {
    console.error("Error updating topic status:", error);
  }
}
function generateSlug(title) {
  return title.toLowerCase().replace(/[^a-z0-9\s-]/g, "").replace(/\s+/g, "-").replace(/-+/g, "-").trim("-").substring(0, 60);
}
async function generateOGImage(slug, title) {
  try {
    const response = await fetch(`${process.env.URL}/.netlify/functions/og-${slug}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title })
    });
    if (response.ok) {
      const result = await response.json();
      return result.path;
    }
  } catch (error) {
    console.error("OG image generation failed:", error);
  }
  return null;
}
async function notifyPipelineFailure(error) {
  try {
    await resend.emails.send({
      from: "Autopilot <system@peycheff.com>",
      to: "ivan@peycheff.com",
      subject: "\u{1F6A8} Autopublish Pipeline Failed",
      html: `
        <div style="font-family: system-ui, sans-serif; padding: 20px;">
          <h2>Pipeline Failure</h2>
          <p><strong>Error:</strong> ${error.message}</p>
          <p><strong>Time:</strong> ${(/* @__PURE__ */ new Date()).toISOString()}</p>
          <p><strong>Stack:</strong></p>
          <pre style="background: #f5f5f5; padding: 10px; overflow: auto;">${error.stack}</pre>
        </div>
      `
    });
  } catch (notifyError) {
    console.error("Failed to notify of pipeline failure:", notifyError);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
