var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var contact_inquiry_exports = {};
__export(contact_inquiry_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(contact_inquiry_exports);
var import_email_service = require("./lib/email-service.js");
const handler = async (event, context) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers,
      body: ""
    };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({
        success: false,
        error: "Method not allowed. Use POST."
      })
    };
  }
  try {
    (0, import_email_service.validateEmailConfig)();
    const inquiry = JSON.parse(event.body);
    const requiredFields = ["name", "email", "linkedin", "problem", "timeline", "budget"];
    const missingFields = requiredFields.filter((field) => !inquiry[field]);
    if (missingFields.length > 0) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({
          success: false,
          error: `Missing required fields: ${missingFields.join(", ")}`
        })
      };
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(inquiry.email)) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({
          success: false,
          error: "Invalid email format"
        })
      };
    }
    if (!inquiry.linkedin.includes("linkedin.com")) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({
          success: false,
          error: "Please provide a valid LinkedIn profile URL"
        })
      };
    }
    const notificationTemplate = import_email_service.EMAIL_TEMPLATES.CONTACT_INQUIRY;
    const notificationResult = await (0, import_email_service.sendEmail)({
      to: notificationTemplate.to,
      subject: notificationTemplate.subject(inquiry),
      html: notificationTemplate.html(inquiry),
      replyTo: inquiry.email
    });
    if (!notificationResult.success) {
      throw new Error(`Failed to send notification email: ${notificationResult.error}`);
    }
    const confirmationTemplate = import_email_service.EMAIL_TEMPLATES.CONTACT_CONFIRMATION;
    const confirmationResult = await (0, import_email_service.sendEmail)({
      to: inquiry.email,
      subject: confirmationTemplate.subject,
      html: confirmationTemplate.html(inquiry),
      replyTo: "ivan@peycheff.com"
    });
    if (!confirmationResult.success) {
      console.warn("Failed to send confirmation email:", confirmationResult.error);
    }
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        message: "Inquiry submitted successfully",
        data: {
          notification_sent: notificationResult.success,
          confirmation_sent: confirmationResult.success,
          inquiry_id: notificationResult.data?.id || null
        }
      })
    };
  } catch (error) {
    console.error("Contact inquiry function error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: "Internal server error. Please try again or email ivan@peycheff.com directly.",
        details: process.env.NODE_ENV === "development" ? error.message : void 0
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
