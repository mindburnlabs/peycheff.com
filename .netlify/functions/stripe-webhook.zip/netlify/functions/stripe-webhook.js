var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var stripe_webhook_exports = {};
__export(stripe_webhook_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(stripe_webhook_exports);
var import_stripe = __toESM(require("stripe"));
var import_supabase_js = require("@supabase/supabase-js");
const stripe = new import_stripe.default(process.env.STRIPE_SECRET_KEY);
const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
const supabase = (0, import_supabase_js.createClient)(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);
const SKU_CONFIG = {
  "CALL_60": {
    name: "Strategy Call (60\u201390 min)",
    type: "service",
    fulfillment: "schedule",
    entitlement: "CALL_60",
    expires_days: null
    // lifetime
  },
  "CALL_PACK": {
    name: "Strategy Call Pack (3 calls)",
    type: "service",
    fulfillment: "schedule",
    entitlement: "CALL_PACK",
    expires_days: 90
    // 90 days to use
  },
  "PACK_30DAY": {
    name: "30-Day Idea\u2192Product Sprint",
    type: "digital",
    fulfillment: "personalize_and_deliver",
    entitlement: "PACK_30DAY",
    expires_days: null
  },
  "KIT_AUTOMATION": {
    name: "Micro-Automation Kit",
    type: "digital",
    fulfillment: "personalize_and_deliver",
    entitlement: "KIT_AUTOMATION",
    expires_days: null
  },
  "KIT_DIAGRAMS": {
    name: "Diagram Library Kit",
    type: "digital",
    fulfillment: "instant_deliver",
    entitlement: "KIT_DIAGRAMS",
    expires_days: null
  },
  "MEMBER_MONTHLY": {
    name: "Build Notes Membership",
    type: "subscription",
    fulfillment: "membership_welcome",
    entitlement: "MEMBER_MONTHLY",
    expires_days: 31
  },
  "MEMBER_ANNUAL": {
    name: "Build Notes Membership (Annual)",
    type: "subscription",
    fulfillment: "membership_welcome",
    entitlement: "MEMBER_ANNUAL",
    expires_days: 366
  },
  "OFFICE_HOURS": {
    name: "Office Hours Seat",
    type: "service",
    fulfillment: "schedule",
    entitlement: "OFFICE_HOURS",
    expires_days: 60
  },
  "DEPOSIT_AUDIT": {
    name: "Systems Audit Deposit",
    type: "service",
    fulfillment: "intake_form",
    entitlement: "DEPOSIT_AUDIT",
    expires_days: null
  },
  "DEPOSIT_SPRINT": {
    name: "Build Sprint Deposit",
    type: "service",
    fulfillment: "intake_form",
    entitlement: "DEPOSIT_SPRINT",
    expires_days: null
  }
};
const handler = async (event, context) => {
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    if (!process.env.STRIPE_SECRET_KEY || !webhookSecret) {
      throw new Error("Stripe configuration is missing");
    }
    if (!process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE_KEY) {
      throw new Error("Supabase configuration is missing");
    }
    const signature = event.headers["stripe-signature"];
    let stripeEvent;
    try {
      stripeEvent = stripe.webhooks.constructEvent(
        event.body,
        signature,
        webhookSecret
      );
    } catch (error) {
      console.error("Webhook signature verification failed:", error.message);
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Invalid signature" })
      };
    }
    console.log("Autopilot webhook received:", stripeEvent.type, stripeEvent.id);
    switch (stripeEvent.type) {
      case "checkout.session.completed":
        await handleCheckoutCompleted(stripeEvent.data.object, stripeEvent.id);
        break;
      case "invoice.payment_succeeded":
        await handleSubscriptionPayment(stripeEvent.data.object, stripeEvent.id);
        break;
      case "customer.subscription.deleted":
        await handleSubscriptionCanceled(stripeEvent.data.object);
        break;
      default:
        console.log(`Unhandled event type: ${stripeEvent.type}`);
    }
    return {
      statusCode: 200,
      body: JSON.stringify({ received: true, event_id: stripeEvent.id })
    };
  } catch (error) {
    console.error("Autopilot webhook error:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: "Webhook processing failed",
        details: process.env.NODE_ENV === "development" ? error.message : void 0
      })
    };
  }
};
async function handleCheckoutCompleted(session, eventId) {
  try {
    console.log("Processing autopilot checkout for session:", session.id);
    const customerEmail = session.customer_details?.email || session.customer_email;
    const productKey = session.metadata?.product_key || inferProductFromSession(session);
    const amount = session.amount_total;
    const source = session.metadata?.source || "website";
    if (!customerEmail || !productKey) {
      console.warn("Missing customer email or product key:", { customerEmail, productKey });
      return;
    }
    const skuConfig = SKU_CONFIG[productKey];
    if (!skuConfig) {
      console.warn(`Unknown SKU: ${productKey}`);
      return;
    }
    await upsertCustomer(customerEmail, session.customer_details?.name);
    const order = await createOrder({
      stripe_event_id: eventId,
      email: customerEmail,
      sku: productKey,
      amount_cents: amount,
      source,
      metadata: session.metadata || {}
    });
    await createEntitlement(customerEmail, skuConfig);
    await dispatchFulfillment(productKey, skuConfig, {
      customer_email: customerEmail,
      session_id: session.id,
      order_id: order.id,
      amount
    });
    console.log(`Autopilot fulfillment dispatched for ${productKey} \u2192 ${customerEmail}`);
  } catch (error) {
    console.error("Error in autopilot checkout:", error);
  }
}
async function handleSubscriptionPayment(invoice, eventId) {
  try {
    console.log("Processing subscription payment:", invoice.id);
    const customer = await stripe.customers.retrieve(invoice.customer);
    const customerEmail = customer.email;
    if (!customerEmail) {
      console.warn("No customer email for subscription payment");
      return;
    }
    if (invoice.billing_reason === "subscription_cycle") {
      const subscription = await stripe.subscriptions.retrieve(invoice.subscription);
      const productKey = inferProductFromSubscription(subscription);
      if (productKey) {
        const skuConfig = SKU_CONFIG[productKey];
        if (skuConfig) {
          await extendEntitlement(customerEmail, skuConfig);
          console.log(`Entitlement extended for ${productKey} \u2192 ${customerEmail}`);
        }
      }
    }
  } catch (error) {
    console.error("Error handling subscription payment:", error);
  }
}
async function handleSubscriptionCanceled(subscription) {
  try {
    console.log("Processing subscription cancellation:", subscription.id);
    const customer = await stripe.customers.retrieve(subscription.customer);
    const customerEmail = customer.email;
    const productKey = inferProductFromSubscription(subscription);
    if (customerEmail && productKey) {
      await expireEntitlement(customerEmail, productKey);
      console.log(`Entitlement expired for ${productKey} \u2192 ${customerEmail}`);
    }
  } catch (error) {
    console.error("Error handling subscription cancellation:", error);
  }
}
async function upsertCustomer(email, name = null) {
  const { data, error } = await supabase.from("customers").upsert({ email, name }, { onConflict: "email" }).select().single();
  if (error) {
    console.error("Error upserting customer:", error);
    throw error;
  }
  return data;
}
async function createOrder(orderData) {
  const { data, error } = await supabase.from("orders").insert(orderData).select().single();
  if (error) {
    console.error("Error creating order:", error);
    throw error;
  }
  return data;
}
async function createEntitlement(email, skuConfig) {
  const expiresAt = skuConfig.expires_days ? new Date(Date.now() + skuConfig.expires_days * 24 * 60 * 60 * 1e3).toISOString() : null;
  const { data, error } = await supabase.from("entitlements").upsert({
    email,
    sku: skuConfig.entitlement,
    expires_at: expiresAt
  }, { onConflict: "email,sku" }).select().single();
  if (error) {
    console.error("Error creating entitlement:", error);
    throw error;
  }
  return data;
}
async function extendEntitlement(email, skuConfig) {
  const newExpiresAt = skuConfig.expires_days ? new Date(Date.now() + skuConfig.expires_days * 24 * 60 * 60 * 1e3).toISOString() : null;
  const { error } = await supabase.from("entitlements").update({ expires_at: newExpiresAt }).eq("email", email).eq("sku", skuConfig.entitlement);
  if (error) {
    console.error("Error extending entitlement:", error);
    throw error;
  }
}
async function expireEntitlement(email, sku) {
  const { error } = await supabase.from("entitlements").update({ expires_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("email", email).eq("sku", sku);
  if (error) {
    console.error("Error expiring entitlement:", error);
    throw error;
  }
}
async function dispatchFulfillment(productKey, skuConfig, purchaseData) {
  const fulfillmentUrl = `${process.env.URL || "https://peycheff.com"}/.netlify/functions/fulfill-${skuConfig.fulfillment.replace("_", "-")}`;
  try {
    const response = await fetch(fulfillmentUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${process.env.FULFILLMENT_SECRET || "default-secret"}`
      },
      body: JSON.stringify({
        sku: productKey,
        config: skuConfig,
        purchase: purchaseData
      })
    });
    if (!response.ok) {
      throw new Error(`Fulfillment failed: ${response.status} ${response.statusText}`);
    }
    const result = await response.json();
    console.log(`Fulfillment dispatched for ${productKey}:`, result);
  } catch (error) {
    console.error(`Fulfillment dispatch failed for ${productKey}:`, error);
  }
}
function inferProductFromSession(session) {
  if (session.metadata?.product_key) {
    return session.metadata.product_key;
  }
  const amount = session.amount_total;
  for (const [sku, config] of Object.entries(SKU_CONFIG)) {
  }
  return null;
}
function inferProductFromSubscription(subscription) {
  if (subscription.metadata?.product_key) {
    return subscription.metadata.product_key;
  }
  const priceId = subscription.items.data[0]?.price?.id;
  const priceToSku = {
    [process.env.VITE_STRIPE_MEMBER_MONTHLY_PRICE_ID]: "MEMBER_MONTHLY",
    [process.env.VITE_STRIPE_MEMBER_ANNUAL_PRICE_ID]: "MEMBER_ANNUAL"
  };
  return priceToSku[priceId] || null;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
