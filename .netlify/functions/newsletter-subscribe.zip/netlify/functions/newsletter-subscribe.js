var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var newsletter_subscribe_exports = {};
__export(newsletter_subscribe_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(newsletter_subscribe_exports);
var import_supabase_js = require("@supabase/supabase-js");
var import_email_service = require("./lib/email-service.js");
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const supabase = (0, import_supabase_js.createClient)(supabaseUrl, supabaseServiceKey);
const handler = async (event, context) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers,
      body: ""
    };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({
        success: false,
        error: "Method not allowed. Use POST."
      })
    };
  }
  try {
    (0, import_email_service.validateEmailConfig)();
    if (!supabaseUrl || !supabaseServiceKey) {
      throw new Error("Supabase configuration is missing");
    }
    const { email, source = "website" } = JSON.parse(event.body);
    if (!email) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({
          success: false,
          error: "Email address is required"
        })
      };
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({
          success: false,
          error: "Invalid email format"
        })
      };
    }
    const { data: existingSubscriber, error: checkError } = await supabase.from("subscribers").select("email, status").eq("email", email).single();
    if (checkError && checkError.code !== "PGRST116") {
      throw new Error(`Database error: ${checkError.message}`);
    }
    let isNewSubscriber = !existingSubscriber;
    let subscriberData = existingSubscriber;
    if (existingSubscriber) {
      if (existingSubscriber.status !== "active") {
        const { data: updatedData, error: updateError } = await supabase.from("subscribers").update({
          status: "active",
          subscribed_at: (/* @__PURE__ */ new Date()).toISOString()
        }).eq("email", email).select().single();
        if (updateError) {
          throw new Error(`Failed to reactivate subscriber: ${updateError.message}`);
        }
        subscriberData = updatedData;
        isNewSubscriber = true;
      }
    } else {
      const { data: newData, error: insertError } = await supabase.from("subscribers").insert([
        {
          email,
          source,
          status: "active",
          subscribed_at: (/* @__PURE__ */ new Date()).toISOString()
        }
      ]).select().single();
      if (insertError) {
        if (insertError.code === "23505") {
          return {
            statusCode: 200,
            headers,
            body: JSON.stringify({
              success: true,
              message: "Already subscribed",
              data: {
                email,
                status: "already_subscribed",
                welcome_sent: false
              }
            })
          };
        }
        throw new Error(`Failed to add subscriber: ${insertError.message}`);
      }
      subscriberData = newData;
    }
    let welcomeEmailResult = { success: false };
    if (isNewSubscriber) {
      const welcomeTemplate = import_email_service.EMAIL_TEMPLATES.NEWSLETTER_WELCOME;
      welcomeEmailResult = await (0, import_email_service.sendEmail)({
        to: email,
        subject: welcomeTemplate.subject,
        html: welcomeTemplate.html({ email }),
        replyTo: "ivan@peycheff.com"
      });
      if (!welcomeEmailResult.success) {
        console.warn("Failed to send welcome email:", welcomeEmailResult.error);
      }
    }
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        message: isNewSubscriber ? "Successfully subscribed!" : "Already subscribed",
        data: {
          email,
          status: isNewSubscriber ? "subscribed" : "already_subscribed",
          welcome_sent: welcomeEmailResult.success,
          subscriber_id: subscriberData.id
        }
      })
    };
  } catch (error) {
    console.error("Newsletter subscription function error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: "Failed to process subscription. Please try again.",
        details: process.env.NODE_ENV === "development" ? error.message : void 0
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
