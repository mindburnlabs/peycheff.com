var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var trigger_autopublish_exports = {};
__export(trigger_autopublish_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(trigger_autopublish_exports);
const handler = async (event, context) => {
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const authHeader = event.headers.authorization;
    if (!authHeader || authHeader !== `Bearer ${process.env.TRIGGER_SECRET}`) {
      return {
        statusCode: 401,
        body: JSON.stringify({ error: "Unauthorized" })
      };
    }
    console.log("Manual autopublish trigger initiated...");
    const autopublishUrl = `${process.env.URL}/.netlify/functions/notes-autopublish`;
    const response = await fetch(autopublishUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "User-Agent": "Manual Trigger"
      }
    });
    const result = await response.json();
    if (!response.ok) {
      throw new Error(`Autopublish failed: ${result.error || "Unknown error"}`);
    }
    return {
      statusCode: 200,
      body: JSON.stringify({
        success: true,
        message: "Autopublish triggered successfully",
        result
      })
    };
  } catch (error) {
    console.error("Manual trigger error:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: "Trigger failed",
        details: process.env.NODE_ENV === "development" ? error.message : void 0
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
